package com.example.richa.maharastraopinionpoll;

import android.Manifest;
import android.animation.Animator;
import android.content.Intent;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;


public class User_info extends AppCompatActivity {

    private ImageView bookIconImageView;
    private TextView bookITextView;
    private ProgressBar loadingProgressBar;
    private RelativeLayout rootView, afterAnimationView;
    private Button submit;
    private EditText NameofUser,Mobileuser,useraddress,usergaaon,uservidhaansabha,district,villa;
    private Double lattitude,longitude;
    private RadioButton rdhule,rnandu;
    private Spinner spinner;
    private static final String[] paths1 = {"item 1", "item 2", "item 3"};
    private static final String[] paths2 = {"item 4", "item 5", "item 6"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_user_info);
        initViews();

        submit=findViewById(R.id.submit);
        NameofUser=findViewById(R.id.NameofUser);
        Mobileuser=findViewById(R.id.Mobileuser);
        useraddress=findViewById(R.id.useraddress);
        usergaaon=findViewById(R.id.usergaaon);
        uservidhaansabha=findViewById(R.id.uservidhaansabha);
        spinner=findViewById(R.id.spinner1);
        villa=findViewById(R.id.villa);
        district=findViewById(R.id.district);
        rdhule=findViewById(R.id.rdhule);
        rnandu=findViewById(R.id.rnandu);

        ActivityCompat.requestPermissions(User_info.this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
        new CountDownTimer(5000, 1000) {

            @Override
            public void onTick(long millisUntilFinished) {
                bookITextView.setVisibility(GONE);
                loadingProgressBar.setVisibility(GONE);
                rootView.setBackgroundColor(ContextCompat.getColor(User_info.this, R.color.colorSplashText));
                bookIconImageView.setImageResource(R.drawable.background_color_book);
                startAnimation();
            }

            @Override
            public void onFinish() {

            }
        }.start();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    GpsTracker g = new GpsTracker(getApplicationContext());
                    Location l = g.getLocation();
                    if (l != null) {
                        lattitude = l.getLatitude();
                        longitude = l.getLongitude();
                        //Toast.makeText(getApplicationContext(), "Lat:" + lat + "\n LON:-" + lon, Toast.LENGTH_LONG).show();
                    }
                    Intent this_intent = getIntent();
                    Intent intent = new Intent(User_info.this, QnA.class);
                    //Log.e("ERRO", this_intent.getStringExtra("Name"));
                    //Toast.makeText(getApplicationContext(), this_intent.getStringExtra("Name"), Toast.LENGTH_LONG).show();
                    if (!Mobileuser.getText().toString().equals("")) {

                        intent.putExtra("0",this_intent.getStringExtra("Name"));
                        intent.putExtra("1",String.valueOf(NameofUser.getText()));
                        intent.putExtra("2",String.valueOf(Mobileuser.getText()));
                        intent.putExtra("3",String.valueOf(useraddress.getText()));
                        intent.putExtra("4",String.valueOf(usergaaon.getText()));
                        intent.putExtra("5",String.valueOf(uservidhaansabha.getText()));
                        String mg="";
                        if(rdhule.isChecked()){
                            mg+="Dhule - ";
                        }else{
                            mg+="Nandurbar - ";
                        }
                        mg+=spinner.getSelectedItem().toString()+" - "+villa.getText().toString();
                        intent.putExtra("6",String.valueOf(mg));
                        intent.putExtra("7",String.valueOf(district.getText()));
                        intent.putExtra("8",String.valueOf(Double.toString(longitude)));
                        intent.putExtra("9",String.valueOf(Double.toString(lattitude)));
                        startActivity(intent);
                    }
                }catch (Exception e){

                }
            }
        });

        rdhule.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(User_info.this,
                            android.R.layout.simple_spinner_item,paths1);

                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(adapter);
                    //spinner.setOnItemSelectedListener(User_info.this);

                }else{
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(User_info.this,
                            android.R.layout.simple_spinner_item,paths2);

                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinner.setAdapter(adapter);
                }
            }
        });
    }


    private void initViews(){
        bookIconImageView = findViewById(R.id.bookIconImageView);
        bookITextView = findViewById(R.id.bookITextView);
        loadingProgressBar = findViewById(R.id.loadingProgressBar);
        rootView = findViewById(R.id.rootView);
        afterAnimationView = findViewById(R.id.afterAnimationView);
    }

    private void startAnimation() {
        ViewPropertyAnimator viewPropertyAnimator = bookIconImageView.animate();
        viewPropertyAnimator.x(50f);
        viewPropertyAnimator.y(100f);
        viewPropertyAnimator.setDuration(1000);
        viewPropertyAnimator.setListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                afterAnimationView.setVisibility(VISIBLE);
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
    }
}

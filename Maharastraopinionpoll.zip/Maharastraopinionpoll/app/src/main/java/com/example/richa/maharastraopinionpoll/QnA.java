package com.example.richa.maharastraopinionpoll;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class QnA extends AppCompatActivity {
    static String decl=" है! मैं पेस मीडया(दिल्ली) से आया हूँ, हम आप लोगों की समस्या को जानना और उस समस्या को मीडिया के माध्यम से सरकार तक पहुँचाना चाहते हैं, जिससे आपकी समस्या का समाधान हो सके! और कृपया निश्चिंत रहे आपके द्वारा दी गई जानकारी पूरी तरह से गोपनीय रखी जाएगी, आपके जवाब दुसरे सहभागियों के जवाब के साथ मलाये जायेंगे और ओपिनियन रिपोटिंग के लिए सिर्फ कुल नतीजो का इस्तमेाल कया जाएगा! क्या हम आपके साथ कुछ समय बात कर सकते है, आपकी राय आपके क्षेत्र के लिए बहुत महत्वपूर्ण है!";
    static String radio_b[] = {"3","6.1","6.2","6.3","6.4","6.5","7.1","7.2","7.3","7.4","8","11","12","13","14","15","16.1","16.2"
            ,"16.3","16.4","16.5","18","19","23","25","26","27","28","29","30.1","30.2","30.3","30.4","30.5","30.6"};
    static String Q[] ={"1: आपके लिए सबसे महत्वपूर्ण समस्या/मुद्दा कौन सा हैं? ",
            "2: जो समस्या आपने बताया है, उसके लिए आप जिम्मेदार किसे मानते हैं? ",
            "3: जो समस्या आपने बताई उसका बेहतर समाधान कौन सी पार्टी कर सकती हैं ?",
            "4: आपके खासदार (सांसद) में इनमे से या क्या समानता हैं ? ",
            "5: आपके खासदार(सांसद) में इनमे से क्या कमजोर हैं ? ",
            "6.1: पिछले ४ वर्षो को आप अपने लिए कैसे देखत हैं ? \n आपकी आय",
            "6.2: पिछले ४ वर्षो को आप अपने लिए कैसे देखत हैं ? \n आपकी बचत",
            "6.3: पिछले ४ वर्षो को आप अपने लिए कैसे देखत हैं ? \n आपका दैनिक जीवन",
            "6.4: पिछले ४ वर्षो को आप अपने लिए कैसे देखत हैं ? \n व्यापर और व्यवसाय के लिए वर्तमान समय",
            "6.5: पिछले ४ वर्षो को आप अपने लिए कैसे देखत हैं ? \n रुपयों के घटते हुए मूल्य",
            "7.1: आप इनके कामकाज को किस तरीके से देखते हैं ? \n आमदार (वधायक) ",
            "7.2: आप इनके कामकाज को किस तरीके से देखते हैं ? \n खासदार (सांसद) ",
            "7.3: आप इनके कामकाज को किस तरीके से देखते हैं ? \n मुख्यमंत्री ",
            "7.4: आप इनके कामकाज को किस तरीके से देखते हैं ? \n प्रधानमंत्री ",
            "8: आपके क्षेत्र में सबसे मजबूत संगठन किस पार्टी का हैं ? ",
            "9: नोटबंदी पे आपका क्या कहना हैं ? ",
            "10: १०% जो स्वर्ण जाती (उच्च जाति) को आरक्षण केंद्र सरकार ने दिया, इस फैसले को आप कैसे देखते हैं? ",
            "11: २०१९ के लोकसभा चुनाव में भाजपा के इसमें सबसे अच्छे उम्मीदवार कौन हो सकते हैं? ",
            "12: २०१९ के लोकसभा चुनाव में कांग्रेस के इसमें सबसे अच्छे उम्मीदवार कौन हो सकते हैं?",
            "13: २०१९ के लोकसभा चुनाव में धुले लोकसभा से सबसे अच्छे उम्मीदवार कौन हैं? ",
            "14: २०१९ में देश में सबसे अच्छे प्रधानमंत्री के उम्मीदवार कौन है? ",
            "15: २०१९ म महाराष्ट्र में सबसे अच्छे मुख्यमंत्री के उम्मीदवार कौन है ? ",
            "16.1: आपके अनुसार निचे लिखी समस्या के कौन जिम्मेदार है ?\nबढती महगाई ",
            "16.2: आपके अनुसार निचे लिखी समस्या के कौन जिम्मेदार है ?\nबढती बरोजगारी",
            "16.3: आपके अनुसार निचे लिखी समस्या के कौन जिम्मेदार है ?\nविकास की धीमी गति",
            "16.4: आपके अनुसार निचे लिखी समस्या के कौन जिम्मेदार है ?\nकसानो क समस्या",
            "16.5: आपके अनुसार निचे लिखी समस्या के कौन जिम्मेदार है ?\nभ्रष्टाचार",
            "17: आपके उपर सबसे अधिक कौन सा मिडिया प्रभाव डालता है ? ",
            "18: आपके वोट डालने के फैसले को सबसे यादा कौन प्रभावित करता है ? ",
            "19: लिंग",
            "20: उम्र",
            "21: शिक्षा",
            "22: व्यवसाय ",
            "23: मासिक पारिवारिक आय ",
            "24: आपकी जाति ",
            "25: आप ने २०१४ वधानसभा में किस पार्टी को वोट दिए थे? ",
            "26: यदि आज विधानसभा चुनाव हुआ तो किस पार्टी को वोट देंगे ? ",
            "27: आप २०१४ लोकसभा में कस पार्टी को वोट दए थे ? ",
            "28: यदि आज लोकसभा चुनाव हुआ तो किस पार्टी को वोट देंगे ? ",
            "29: यदि आपके वर्तमान सांसद पुनः चुनाव लड़ते हैं, तो आप उनको वोट देना पसंद करेंगे? ",
            "30.1: आप इनका कतना प्रयोग करते है ? \nफेसबुक",
            "30.2: आप इनका कतना प्रयोग करते है ? \nव्हाटसैप",
            "30.3: आप इनका कतना प्रयोग करते है ? \nयुट्यूब",
            "30.4: आप इनका कतना प्रयोग करते है ? \nट्विटर",
            "30.5: आप इनका कतना प्रयोग करते है ? \nन्यूज पोटल",
            "30.6: आप इनका कतना प्रयोग करते है ? \nइन्स्टाग्राम"};

    static String option1[][] = {{"1: बेरोजगारी","2: बढती हुई महंगाई","3: भूमि अधिग्रहण के समय किये गये वादे पूरा नहीं करना","4: पीने के पानी की कमी","5: भ्रष्टाचार","6: सार्वजानिक परिवहन की स्थिति","7: कानून व्यवस्थता की स्थिति","8: textbox:अन्य","0: पता नहीं/ नहीं जनता"},
            {"1: नगरसेवक","2: आमदार (विधायक)","3: मुख्यमंत्री","4: खासदार (सांसद)","5: प्रधानमंत्री","0: नहीं पता"},
            {"1: भाजपा","2: शिवसेना","3: राष्ट्रवादी कांग्रेस पार्टी","4: कांग्रेस","5: मनसे","0: नहीं पता"},
            {"1: जनता के लिए आसानी से उपलब्ध","2: क्षेत्र के विकास के लिए सक्रीय","3: साफ़ छवि","4: जनता के साथ अच्छा व्व्यहार","0: नहीं पता"},
            {"1: जनता के क्षेत्र से दुरी","2: विकास कार्यो की अनदेखी","3: आम जन के साथ ख़राब व्यव्हार","4: भ्रष्टाचार में शामिल","5: सार्वजानिक कार्य करने में असक्षम","6: कोई नहीं"},
            {"1: बढ़ी है, बेहतर हुई है","2: कम हुई है, ख़राब हुई है","3: पहले जैसे है, कोई वदलाव नहीं है","0: पता नहं, नहं जानत"},
            {"1: बढ़ी है, बेहतर हुई है","2: कम हुई है, ख़राब हुई है","3: पहले जैसे है, कोई वदलाव नहीं है","0: पता नहं, नहं जानत"},
            {"1: बढ़ी है, बेहतर हुई है","2: कम हुई है, ख़राब हुई है","3: पहले जैसे है, कोई वदलाव नहीं है","0: पता नहं, नहं जानत"},
            {"1: बढ़ी है, बेहतर हुई है","2: कम हुई है, ख़राब हुई है","3: पहले जैसे है, कोई वदलाव नहीं है","0: पता नहं, नहं जानत"},
            {"1: बढ़ी है, बेहतर हुई है","2: कम हुई है, ख़राब हुई है","3: पहले जैसे है, कोई वदलाव नहीं है","0: पता नहं, नहं जानत"},
            {"1: बहुत ख़राब","2: ख़राब","3: सामान्य ","4: अच्छा","5: बहुत अच्छा "},
            {"1: बहुत ख़राब","2: ख़राब","3: सामान्य ","4: अच्छा","5: बहुत अच्छा "},
            {"1: बहुत ख़राब","2: ख़राब","3: सामान्य ","4: अच्छा","5: बहुत अच्छा "},
            {"1: बहुत ख़राब","2: ख़राब","3: सामान्य ","4: अच्छा","5: बहुत अच्छा "},
            {"1: भाजपा","2: शिवसेना","3: राष्ट्रवादी कांग्रेस पार्टी","4: कांग्रेस","5: मनसे","6: किसी का भी नहीं"},
            {"1: ये एक अच्छा फैसला था ","2: ये एक गलत फैसला था ","3: आम लोग को बहुत तकलीफ हुई","4: रोजगार और नौकरी में कमी हुई"},
            {"1: सही निर्णय लिया गया है","2: ये चुनाव को देख के फैसला लिया गया","3: पिछडो और दलित का नुकसान होगा","4: स्वर्ण गरीब को भी फायदा मिलेगा","5: किसीको कुछ लाभ नहीं होगा  ","0: नहीं पता "},
            {"1: डा. सुभाष भामरे ","2: डॉ माधुर बोरसे ","3: सुभाष देवरे "},
            {"1: रोहिदास पाटिल ","2: शिवाजीराव दहिते ","3: डॉ तुषार शेवाले ","4: अमरीश भाई पटेल"},
            {"1: डा. सुभाष भामरे (भाजपा)","2: डॉ माधुर बोरसे (भाजपा)","3: रोहिदास पाटिल (कांग्रेस)","4: शिवाजीराव दहिते (कांग्रेस)","5: सुभाष देवरे (भाजपा) ","6: अमरीश भाई पटेल (कांग्रेस)","7: डॉ तुषार शेवाले (कांग्रेस)","8: textbox:अन्य"},
            {"1: नरेन्द्र मोदी ","2: राहुल गाँधी ","3: शरद पवार","4: नितिन गडकरी ","5: मनमोहन सिंह","6: textbox:अन्य","0: नही पता "},
            {"1: देवेन्द्र फडनविस ","2: उद्धव ठाकरे ","3: अजित पवार ","4: अशोक चव्हाण ","5: राज ठाकरे ","6: textbox:अन्य","0: पता नही "},
            {"1: आमदार","2: मुख्यमंत्री","3: खासदार","4: प्रधानमंत्री","0: नहीं पता"},
            {"1: आमदार","2: मुख्यमंत्री","3: खासदार","4: प्रधानमंत्री","0: नहीं पता"},
            {"1: आमदार","2: मुख्यमंत्री","3: खासदार","4: प्रधानमंत्री","0: नहीं पता"},
            {"1: आमदार","2: मुख्यमंत्री","3: खासदार","4: प्रधानमंत्री","0: नहीं पता"},
            {"1: आमदार","2: मुख्यमंत्री","3: खासदार","4: प्रधानमंत्री","0: नहीं पता"},
            {"1: टेलीविज़न ","2: समाचार पत्र ","3: युट्यूब","4: ट्विटर","5: न्यूज पोर्टल ","6: फेसबुक ","7: व्हाटसैप","0: कोई नहीं"},
            {"1: आपका अपना नजरिया ","2: आपके परिवार का नजरिया ","3: टेलीविज़न","4: न्यूज पेपर","5: सोसल मिडिया ","6: दोस्तों का नजरिया"},
            {"1: पुरुष","2: महिला"},
            {"1: textbox:उम्र"},
            {"1: निरक्षर","2: साक्षर ","3: प्राथमिक ","4: हाई स्कूल","5: इंटर ","6: स्नातक","7: स्नातकोत्तर","8: व्यावसायिक (प्रोफेशनल)"},
            {"1: विद्यार्थी","2: बेरोजगार","3: घरेलु महिला","4: किसान","5: खेतिहर मजदुर","6: पशु पालन","7: सरकारी नौकरी","8: प्राइवेट नौकरी","9: अपना व्यवसाय","10: मजदुर","11: अन्य"},
            {"1: 3000 से कम","2: 3000-6000 तक","3: 6000-10,000 तक","4: 10,000-20,000 तक","5: 20,000-50,000 तक","6: 50,000-1,00,000 तक","7: 1,00,000 से अधिक","0: पता नही / कह नही सकते "},
            {"1: सामान्य ","2: ओ बी सी ","3: एस सी ","4: एस टी","5: अन्य"},
            {"1: भाजपा","2: शिवसेना","3: राष्ट्रवादी कांग्रेस पार्टी","4: कांग्रेस","5: मनसे","6: अन्य ","7: नहीं बता सकते"},
            {"1: भाजपा","2: शिवसेना","3: राष्ट्रवादी कांग्रेस पार्टी","4: कांग्रेस","5: मनसे","6: अन्य ","7: नहीं बता सकते"},
            {"1: भाजपा","2: शिवसेना","3: राष्ट्रवादी कांग्रेस पार्टी","4: कांग्रेस","5: मनसे","6: अन्य ","7: नहीं बता सकते"},
            {"1: भाजपा","2: शिवसेना","3: राष्ट्रवादी कांग्रेस पार्टी","4: कांग्रेस","5: मनसे","6: अन्य ","7: नहीं बता सकते"},
            {"1: हां","2: नही ","3: नहीं पता "},
            {"1: दिन में कई बार ","2: दिन में एक बार ","3: सप्ताह में २-३ बार ","4: सप्ताह में एक बार ","5: उपयोग नही करता"},
            {"1: दिन में कई बार ","2: दिन में एक बार ","3: सप्ताह में २-३ बार ","4: सप्ताह में एक बार ","5: उपयोग नही करता"},
            {"1: दिन में कई बार ","2: दिन में एक बार ","3: सप्ताह में २-३ बार ","4: सप्ताह में एक बार ","5: उपयोग नही करता"},
            {"1: दिन में कई बार ","2: दिन में एक बार ","3: सप्ताह में २-३ बार ","4: सप्ताह में एक बार ","5: उपयोग नही करता"},
            {"1: दिन में कई बार ","2: दिन में एक बार ","3: सप्ताह में २-३ बार ","4: सप्ताह में एक बार ","5: उपयोग नही करता"},
            {"1: दिन में कई बार ","2: दिन में एक बार ","3: सप्ताह में २-३ बार ","4: सप्ताह में एक बार ","5: उपयोग नही करता"}};
    String option2[] ={"2.1: गैस के बढ़ते दाम","2.2: बिजली के बढ़ते दाम","2.3: खाद्यपदार्थ के बढ़ते दाम","2.4: पेट्रोल डीजल के बढ़ते दाम","2.5: पब्लिक ट्रंसपोट के बढ़ते दाम"};
    private TextView tv;
    private LinearLayout ll;
    private Button bn;
    private Button back;
    static int index = -1;
    ArrayList al = new ArrayList();
    String bflag="";
    ArrayList<String> ral;
    //RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qn);
        tv = findViewById(R.id.textView);
        ll = findViewById(R.id.ll);
        bn = findViewById(R.id.button2);
        //rg = findViewById(R.id.rg);

        List<String> newList = Arrays.asList(radio_b);
        ral = new ArrayList<String>();
        ral.addAll(newList);

        Log.e("ERRO", option1.length+"O:Q"+Q.length);
        Intent intent = getIntent();
        //nextQ(bn.getRootView());
        tv.setText("नमस्ते मेरा नाम "+intent.getStringExtra("0")+decl);
    }
    public void backQ(View view){
        if(index>1){
            bflag = al.get(index-2).toString();
            index-=2;
            nextQ(view);
        }
        else{
            index=-1;
            al.remove(0);
            al.remove(1);
            ll.removeAllViews();
            nextQ(view);

        }



    }
    public void nextQ(View view){
        try {
            if(index<Q.length) {
                String msg = "";

                boolean flag = false;
                boolean radioflag = true;
                if(index>-1) {
                    if (ral.contains(Q[index].split(":")[0])) {
                        for (int i = 0; i < ll.getChildCount(); i++) {
                            View v = (View) ll.getChildAt(i);
                            if (v instanceof RadioGroup) {
                                RadioGroup rg = (RadioGroup) v;
                                for (int j = 0; j < rg.getChildCount(); j++) {
                                    View v1 = (View) rg.getChildAt(j);
                                    if (v1 instanceof RadioButton) {
                                        RadioButton rb = (RadioButton) v1;
                                        if (rb.isChecked()) {
                                            msg += rb.getText().toString();
                                            radioflag = false;
                                            break;
                                        }
                                    }
                                }
                            } else if (v instanceof EditText) {
                                EditText et = (EditText) v;
                                if (radioflag) msg += et.getText().toString();

                            }
                        }
                        for (int i = 0; i < ll.getChildCount(); i++) {
                            View v = ll.getChildAt(i);
                            if (v instanceof EditText) {
                                EditText et = (EditText) v;
                                if (radioflag) msg += et.getText().toString() + ",";
                            }
                        }
                    } else {
                        for (int i = 0; i < ll.getChildCount(); i++) {
                            View v = (View) ll.getChildAt(i);
                            if (v instanceof CheckBox) {
                                CheckBox cbb = (CheckBox) v;
                                if (index == 0) {
                                    if (cbb.getText().toString().equals("2: बढती हुई महंगाई") && cbb.isChecked())
                                        flag = true;
                                }
                                if (cbb.isChecked()) msg += cbb.getText().toString() + ",";
                            } else if (v instanceof EditText) {
                                EditText e = (EditText) v;
                                if (!e.getText().toString().equals("")) {
                                    if (flag) msg += "8: " + e.getText().toString() + ",";
                                    else
                                        msg += option1[index][i].split(":")[0] + ": " + e.getText().toString() + ",";
                                }
                            }
                        }
                    }
                }
                if(index>-1) al.add(index,msg);
                if(!bflag.equals("")){ al.add(index,bflag);bflag="";}



                if (bn.getText() == "Submit") {
                    Intent this_intent = getIntent();
                    Intent itt = new Intent(this, Submission.class);
                    for(int i=0;i<10;i++){
                        itt.putExtra(i+"",this_intent.getStringExtra(i+""));
                    }
                    for (int i = 0+10; i < al.size()+10; i++) {
                        itt.putExtra(i + "", String.valueOf(al.get(i-10)));
                    }
                    startActivity(itt);
                    finish();
                }
                index++;
                if (index == option1.length - 1) bn.setText("Submit");
                tv.setText(Q[index]);
                ll.removeAllViews();
                RadioGroup rg = new RadioGroup(this);
                ll.addView(rg);
                for (String str : option1[index]) {

                    if(ral.contains(Q[index].split(":")[0])){

                        if (str.split(":")[1].equals(" textbox")) {
                            EditText et = new EditText(this);
                            et.setHint(str.split(":")[0] + ":" + str.split(":")[2]);
                            ll.addView(et);
                        } else {
                            RadioButton rb = new RadioButton(this);
                            rb.setText(str);
                            //rb.setOnClickListener(getOnClickDoSomething(rb));
                            rg.addView(rb);
                        }

                    }else{
                        if (str.split(":")[1].equals(" textbox")) {
                            EditText et = new EditText(this);
                            et.setHint(str.split(":")[0] + ":" + str.split(":")[2]);
                            ll.addView(et);
                        } else {
                            CheckBox cb = new CheckBox(this);
                            cb.setText(str);
                            cb.setOnClickListener(getOnClickDoSomething(cb));
                            ll.addView(cb);
                        }
                    }

                }
            }
        }catch (Exception ex){
            Log.e("ERRO", ex.getMessage()+":"+index);
        }
    }
    View.OnClickListener getOnClickDoSomething(final CheckBox checkBox){
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (checkBox.getText().equals("2: बढती हुई महंगाई") && checkBox.isChecked()) {
                        ll.removeAllViews();
                        //for (int j = 0; j < option1[index].length; j++) {
                        for(String str: option1[index]){
                            if (str.split(":")[1].equals(" textbox")) {

                                EditText et = new EditText(QnA.this);
                                et.setHint(str.split(":")[0] + ":" + str.split(":")[2]);
                                ll.addView(et);
                            } else {
                                CheckBox cb1 = new CheckBox(QnA.this);
                                cb1.setOnClickListener(getOnClickDoSomething(cb1));
                                cb1.setText(str);
                                if (str.equals("2: बढती हुई महंगाई")) {
                                    //cb1.setChecked(true);
                                    ll.addView(checkBox);
                                    for (int i = 0; i < option2.length; i++) {
                                        CheckBox cb = new CheckBox(QnA.this);
                                        cb.setText(option2[i]);
                                        cb.setOnClickListener(getOnClickDoSomething(cb));
                                        ll.addView(cb);
                                    }
                                } else {
                                    ll.addView(cb1);
                                }
                            }
                        }

                    } else if (checkBox.getText().equals("2: बढती हुई महंगाई") && !checkBox.isChecked()) {
                        Toast.makeText(getApplicationContext(), checkBox.getText() + Boolean.toString(checkBox.isChecked()), Toast.LENGTH_LONG).show();
                        ll.removeAllViews();
                        for (int j = 0; j < option1[index].length; j++) {
                            if (option1[index][j].split(":")[1].equals(" textbox")) {
                                EditText et = new EditText(QnA.this);
                                et.setHint(option1[index][j].split(":")[0] + ":" + option1[index][j].split(":")[2]);
                                ll.addView(et);
                            } else {
                                CheckBox cb1 = new CheckBox(QnA.this);
                                cb1.setText(option1[index][j]);
                                cb1.setOnClickListener(getOnClickDoSomething(cb1));
                                if (option1[index][j].equals("2: बढती हुई महंगाई"))
                                    ll.addView(checkBox);
                                ll.addView(cb1);
                            }
                        }
                    }
                    Toast.makeText(getApplicationContext(), checkBox.getText() + Boolean.toString(checkBox.isChecked()), Toast.LENGTH_LONG).show();
                }catch (Exception e){
                    Log.e("ERRO_Listner",e.getMessage());
                }
            }
        };
    }
    @Override
    protected void onResume() {
        super.onResume();
        index=-1;
    }
}


package com.example.richa.maharastraopinionpoll;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class Submission extends AppCompatActivity {
    static final String INDEX[]={"1:","2:","3:","4:","5:","6.1:","6.2:","6.3","6.4:","6.5:",
            "7.1:","7.2:","7.3:","7.4:","8:","9:","10:","11:","12:","13:",
            "14:","15:","16.1:","16.2:","16.3:","16.4:","16.5:","17:","18:","19:","20:","21:","22:","23:","24:",
            "25:","26:","27:","28:","29:","30.1:","30.2:","30.3","30.4","30.5","30.6"};
    String name[] = {"abhi","ravi","nody","kitty"};
    ConnectionClass connectionClass;
    ArrayList<String> al = new ArrayList<>();
    LocalDB ldb;
    TextView wv;
    Button b2 ;
    Button lto;

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submission);
        Intent intent = getIntent();
        wv = findViewById(R.id.test);
        b2 = findViewById(R.id.show);
        lto = findViewById(R.id.lto);
        ldb = new LocalDB(this,null,null,1);
        connectionClass = new ConnectionClass();
        Button bn = findViewById(R.id.bn);
        /*al.add("Rohan");
        al.add("Abhinav");//uname
        al.add("593400116");//mob
        al.add("Ranchi");//address
        al.add("jogna");//vill
        al.add("jogna");//vidhan
        al.add("lohardaga");//u_booth
        al.add("senha");//u_district
        al.add("vxdj");//u_longi
        al.add("krsd");*/
        for(int i=0;i<INDEX.length+10;i++){
            al.add(intent.getStringExtra(i+""));
            wv.append(i+"::"+intent.getStringExtra(i+"")+"\n");
        }
        try {
            Log.e("ERRO",insertQuery1(al));
        }catch (Exception e){
            Log.e("ERRO",e.getMessage());
        }

        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //wv.setText(insertQuery1(al));
                Log.e("Query",insertQuery1(al));
                DoLogin doLogin = new DoLogin();
                doLogin.execute("");

            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    String str="";
                    ArrayList<String> al=ldb.readDB();
                    for(int i=0;i<al.size();i++){
                        str+=al.get(i)+"\n";
                    }
                    wv.setText(str);
                }catch (Exception e){
                    Toast.makeText(Submission.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                }


            }
        });
        lto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    ArrayList<String> total = new ArrayList<String>();
                    total = ldb.readDB();
                    al = ldb.readDB1(total.get(0));
                    for(int i=0;i<al.size();i++) wv.append(al.get(i));
                    String str[]={total.get(0)};
                    ldb.deleterow(str);
                    DoLogin doLogin = new DoLogin();
                    doLogin.execute("");

                }catch (Exception e){
                    Toast.makeText(Submission.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    String insertQuery1(ArrayList<String> a){
        int count=1;
        String begin="insert into pdata values(";
        String ending=");";
        String middle="N'"+a.get(0)+"'";
        for(int i=1;i<a.size();i++){
            middle+=",N'"+a.get(i)+"'";
            count++;
        }
        Log.e("COUNT",count+"");
        return begin+middle+ending;

    }
    public class DoLogin extends AsyncTask<String,String,String> {
        String z = "";
        Boolean isSuccess = false;
        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onPostExecute(String r) {
            Toast.makeText(Submission.this,r,Toast.LENGTH_SHORT).show();
            if(!isSuccess) {
                try{
                    //for(int i=0;i<name.length;i++)
                    ldb.addrow(al);
                    Toast.makeText(Submission.this,"Failed",Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(Submission.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        protected String doInBackground(String... params) {
            try {
                Connection con = connectionClass.CONN();
                if (con == null) {
                    z = "Error in connection with SQL server";
                } else {
                    Statement stmt = con.createStatement();
                    //for(int i=1;i<al.size();i++){
                    Log.e("Do in back",insertQuery1(al));
                    ResultSet rs = stmt.executeQuery("select u_mobile from pdata where u_mobile = "+al.get(2));
                    if(rs.next()){ z="Already Exist"; isSuccess=true;}
                    else{
                        int a = stmt.executeUpdate(insertQuery1(al));
                        //int a = stmt.executeUpdate("insert into pdata ([index],opinion) values('"+INDEX[i]+"',N'"+al.get(i)+"');");
                        if(a>0) {
                            z = "Inserted into table";
                            isSuccess=true;
                        }
                        else {
                            z = "Invalid Credentials";
                            isSuccess = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions : "+ex.toString()+":"+ex.getMessage();
            }
            return z;
        }
    }




    public void newRegi(View view){
        Intent u_info = new Intent(Submission.this,User_info.class);
        startActivity(u_info);

    }


}

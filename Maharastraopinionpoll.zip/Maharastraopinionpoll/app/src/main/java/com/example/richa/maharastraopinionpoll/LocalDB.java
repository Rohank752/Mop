package com.example.richa.maharastraopinionpoll;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class LocalDB extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private  static final String DATABASE_NAME = "lpeople.db";
    public static final String TABLE_NAME = "ltable";
    String col[]={"s_name","u_name","u_mob","u_address","u_village","u_vidhan","u_booth","u_district","u_longi","u_lati","Q1","Q2","Q3",
            "Q4","Q5","Q6_1","Q6_2","Q6_3","Q6_4","Q6_5","Q7_1","Q7_2","Q7_3","Q7_4","Q8","Q9","Q10","Q11",
            "Q12","Q13","Q14","Q15","Q16_1","Q16_2","Q16_3","Q16_4","Q16_5","Q17","Q18","Q19","Q20","Q21",
            "Q22","Q23","Q24","Q25","Q26","Q27","Q28","Q29","Q30_1","Q30_2","Q30_3","Q30_4","Q30_5","Q30_6"};

    public LocalDB(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //onUpgrade(sqLiteDatabase,0,0);
        String query = "Create Table "+TABLE_NAME+"(s_name TEXT,u_name TEXT,u_mob INTEGER PRIMARY KEY AUTOINCREMENT,u_address TEXT,u_village TEXT," +
                "u_vidhan TEXT,u_booth TEXT,u_district TEXT,u_longi TEXT,u_lati TEXT,Q1 TEXT,Q2 TEXT,Q3 TEXT,Q4 TEXT,Q5 TEXT,Q6_1 TEXT," +
                "Q6_2 TEXT,Q6_3 TEXT,Q6_4 TEXT,Q6_5 TEXT," +
                "Q7_1 TEXT,Q7_2 TEXT,Q7_3 TEXT,Q7_4 TEXT,Q8 TEXT,Q9 TEXT,Q10 TEXT,Q11 TEXT" +
                ",Q12 TEXT,Q13 TEXT,Q14 TEXT,Q15 TEXT,Q16_1 TEXT,Q16_2 TEXT,Q16_3 TEXT,Q16_4 TEXT,Q16_5 TEXT,Q17 TEXT," +
                "Q18 TEXT,Q19 TEXT,Q20 TEXT,Q21 TEXT,Q22 TEXT,Q23 TEXT," +
                "Q24 TEXT,Q25 TEXT,Q26 TEXT,Q27 TEXT,Q28 TEXT,Q29 TEXT," +
                "Q30_1 TEXT,Q30_2 TEXT,Q30_3 TEXT,Q30_4 TEXT,Q30_5 TEXT,Q30_6 TEXT);";
        //String query = "CREATE TABLE "+TABLE_NAME+"(u_name TEXT,u_mob INTEGER PRIMARY KEY AUTOINCREMENT,Q1 TEXT);";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
    public boolean deleterow(String[] mob){
        Boolean bool = false;
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NAME,"u_mob=?",mob);
        return  bool;
    }
    public void addrow(ArrayList<String> a){
        ContentValues contentValues = new ContentValues();
        for(int i=0;i<col.length;i++)
            contentValues.put(col[i],a.get(i));
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TABLE_NAME,null,contentValues);
        db.close();
    }
    public ArrayList<String> readDB(){
        ArrayList<String> al = new ArrayList<String>();
        SQLiteDatabase db = getWritableDatabase();
        String query = "Select u_mob from "+TABLE_NAME;
        Cursor c = db.rawQuery(query,null);

        c.moveToFirst();
        while(!c.isAfterLast()){
            for(int i=0;i<c.getColumnCount();i++){
                al.add(c.getString(i));
            }
            c.moveToNext();
        }
        return  al;
    }
    public ArrayList<String> readDB1(String mob){
        ArrayList<String> al = new ArrayList<>();
        SQLiteDatabase db = getWritableDatabase();
        String query = "Select * from "+TABLE_NAME+" where u_mob = "+mob+";";
        Cursor c = db.rawQuery(query,null);
        c.moveToNext();
        while(!c.isAfterLast()){
            for(int i=0;i<c.getColumnCount();i++){
                al.add(c.getString(i));
            }
            c.moveToNext();
        }
        return  al;

    }



}
